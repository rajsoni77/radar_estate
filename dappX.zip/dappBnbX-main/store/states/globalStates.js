export const globalStates = {
  appartments: [],
  appartment: null,
  reviews: [],
  reviewModal: 'scale-0',
  securityFee: 0,
  bookings: [],
  booking: null,
  timestamps: [],
}
